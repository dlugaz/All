../../tools/modpoll -m rtu -a 10 -r 1000 -c 4 -t 3 -b 38400 -d 8 -p even /dev/ttyS0
